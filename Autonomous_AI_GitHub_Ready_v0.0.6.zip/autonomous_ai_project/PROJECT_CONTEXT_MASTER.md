# Autonomous AI — Master Project Context / Handoff

This is the portable, authoritative project brief for continuing the work in another AI assistant. Read this first, then `README.md` and every file in `docs/`. Treat source code, tests, checkpoints and experiment reports as the evidence of implementation status. Do not assume the vision is implemented merely because it is documented.

## Owner's intent
Build an independent, locally running learning entity from scratch—not a scripted chatbot and not a wrapper around an existing AI. It should develop capabilities, memory, individual interests, computational affect, self-directed goals and research through both information study and interaction. The owner is an observer/participant, not a task dispatcher.

## Non-negotiables
- No external AI model, API, or real Internet connection for the agent.
- No pretrained model or pretrained weights silently introduced.
- No scripts/behavior trees/fixed dialogue/answer tables masquerading as cognition. Infrastructure scripts are allowed.
- Prepare and maintain a GitHub-ready repository because the owner works from a phone. Do not publish/push to a remote repository until the owner explicitly confirms the target repository and publication.
- Isolated synthetic Internet/world with real simulated state and coherent connections.
- The simulated world includes positive and negative information/behaviors and morally complex situations; the learner compares evidence and consequences to develop/revise its own concepts. Do not hardcode a morality lookup table. Keep dangerous situations contained and non-actionable for real-world harm.
- The learner must interact, not merely read: page navigation, links, buttons, text entry, forms, menus, scrolling, app/tool affordances and state changes. Owner sees/replays the activity, including action, target, result and timestamp; attempted and successful actions are distinct.
- Autonomous activity is the default, including self-selected learning, goals, questions, hypotheses and experiments, while the host is available. Provide runtime scheduling, recovery/checkpoints, resource limits, and owner pause/stop controls. A powered-off local machine cannot run.
- Keep evidence honest: no claims of learning, skill, progress, intelligence or metric improvement without measurements and tests.

## Developmental starting point
A metaphorical early-childhood foundation (~3 years): basic Russian/English, simple language, arithmetic, elementary logic, causal relations and common concepts. It is a starter foundation, not a hard age ceiling or biological equivalence. Later capabilities must be acquired through learning.

## Agreed systems
- Learning from both materials and interactive experience.
- Autonomous exploration and long-term goals; independently form questions/hypotheses and conduct experiments.
- Cognitive capability, developing individual profile, and computational affective signals (not proof of subjective feelings/consciousness).
- Memory: working, long-term, episodic, semantic and procedural; learn memory management, consolidation, retrieval and revising beliefs, while preserving recoverable history.
- Owner interaction: text chat, voice, activity monitor, collaborative work and ability to introduce feedback/materials. Interaction does not replace autonomous activity.
- Continuous operation while host is available; overnight consolidation/training, evaluation and candidate checkpoint comparisons. Only promote tested improvements; preserve rollback.
- Monitoring: current activity, goals, hypotheses, experiments, actions, outcomes, training/evaluation metrics, memory/skills changes, resources, logs, checkpoints and concise audit summaries. Do not expose or fabricate hidden chain-of-thought.

## Access and compute constraints
Owner works from an Android phone and does not have a computer. Use GitHub mobile/web and GitHub Codespaces for browser-based development where available. Codespaces availability, quota, compute, storage and idle shutdown depend on the GitHub account. Do not promise always-on free compute. Small CPU experiments are feasible; frontier-scale training from scratch is not.

## Current implementation snapshot
Version 0.0.6 is GitHub-ready and includes a randomly initialized causal Transformer experiment, corpus-derived character tokenizer, training/evaluation script, event journal, tests, and browser dashboard. `.github/workflows/tests.yml` runs compile checks and pytest; `.devcontainer/devcontainer.json` configures Python 3.11 Codespaces. On a private Codespace, launch with `python -m src.ai_core.dashboard --host 0.0.0.0 --port 8765` and keep forwarded port 8765 Private. The dashboard has no authentication. The owner-only Internet tab opens links/search in the owner browser; the learner has no real-Internet client. The temporary character-level text continuation is not a semantic chatbot. A standalone isolation policy primitive has unit tests but is not integrated end-to-end. The synthetic Internet, autonomous goals, mature memory and continuous learning are not implemented. Eight project tests pass. No GitHub repository has been created or published by this packaging step.

## Next engineering priorities
1. Validate the dashboard and training in the owner’s private GitHub Codespace; do not assume GPU availability.
2. Improve the neural learning experiment and evaluation/generalization tests, preserving from-scratch initialization.
3. Define observation/action/result experience records and memory persistence.
4. Build the first small local interactive environment, then browser-like controls and observable action replay.
5. Integrate owner-request mode with frozen model/knowledge snapshots and isolated synthetic-world browser; prove no leakage into autonomous memory/training with integration tests.
6. Implement a runtime/scheduler that autonomously selects activity, can run unattended while host is available, checkpoints and recovers.
7. Add goal/hypothesis/experiment tracking and expand monitor UI only after underlying events/data are real.
8. Expand synthetic Internet content gradually into a diverse, interconnected, morally mixed world.

## How a new AI should proceed
Do not ask settled conceptual questions again. Make reasonable implementation decisions, document assumptions and work in small milestones. Start by inspecting all files and running tests. Never alter project direction or use remote services without owner permission. For each milestone: provide complete files/changes, run tests, report what is actually verified and limitations, and update `docs/CHANGELOG.md`, `docs/ROADMAP.md`, `docs/ARCHITECTURE.md`, `docs/DECISIONS.md`, `docs/HANDOFF.md` and this context file as applicable. Keep a dated backup before risky changes.

## Owner request mode — new requirement
The owner can use the agent and browse the local synthetic Internet. Ordinary requests must be isolated from autonomous development: pinned checkpoint and knowledge snapshot, temporary context, isolated/read-only world snapshot, and no changes to autonomous memory, training data/replay, goals, weights, or world state. Temporary context is discarded at session close. Owner convenience history, if implemented, must be separate and learner-inaccessible. Explicit teaching is a separate opt-in workflow. This does not authorize real external Internet or APIs. See spec section 16. A policy primitive exists but is not yet wired end-to-end; tests are unit tests only.


## Phone-first workflow update (2026-11-21)
Owner has no computer and works from an Android phone. Do not give Windows/.bat/local-PC setup steps. Repository v0.0.6 includes `.devcontainer/devcontainer.json`, `.github/workflows/tests.yml`, `requirements-dev.txt`, and dashboard host binding for private Codespaces port forwarding. Use GitHub Codespaces for browser-based coding/running if available; its quota/billing and idle shutdown apply. Dashboard has no authentication, so keep forwarded port Private. CI runs compileall and pytest. Project is GitHub-ready, but no remote repository has been created or published in this packaging step.
