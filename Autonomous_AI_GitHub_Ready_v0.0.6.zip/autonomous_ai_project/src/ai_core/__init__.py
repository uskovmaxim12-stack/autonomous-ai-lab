"""Local infrastructure foundation for the autonomous learning project."""
__version__ = "0.0.1"
