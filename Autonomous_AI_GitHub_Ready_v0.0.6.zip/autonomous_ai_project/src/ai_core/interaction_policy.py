"""Policy primitives for owner-request sessions, isolated from autonomous learning.

This module enforces session metadata only. It is not yet wired to a model or
virtual-world browser; integration is a future milestone and must preserve these
invariants.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from uuid import uuid4


@dataclass(frozen=True)
class OwnerSessionPolicy:
    use_current_checkpoint_only: bool = True
    allow_training_updates: bool = False
    allow_autonomous_memory_writes: bool = False
    allow_goal_updates: bool = False
    allow_experience_replay_ingestion: bool = False
    allow_world_mutations: bool = False
    isolated_world_snapshot: bool = True
    discard_temporary_context_on_close: bool = True

    def validate(self) -> None:
        """Raise if the session policy is accidentally configured as learning."""
        forbidden = (
            self.allow_training_updates,
            self.allow_autonomous_memory_writes,
            self.allow_goal_updates,
            self.allow_experience_replay_ingestion,
            self.allow_world_mutations,
        )
        if any(forbidden):
            raise ValueError("Owner request sessions must remain isolated from autonomous learning")
        if not self.use_current_checkpoint_only or not self.isolated_world_snapshot:
            raise ValueError("Owner request sessions must use a frozen checkpoint and isolated snapshot")


@dataclass
class OwnerRequestSession:
    """Temporary context for a single owner request; never a training record."""
    request_text: str
    policy: OwnerSessionPolicy = field(default_factory=OwnerSessionPolicy)
    session_id: str = field(default_factory=lambda: str(uuid4()))
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    temporary_context: list[str] = field(default_factory=list)
    closed: bool = False

    def __post_init__(self) -> None:
        self.policy.validate()

    def add_temporary_context(self, item: str) -> None:
        if self.closed:
            raise RuntimeError("Session is closed")
        self.temporary_context.append(item)

    def close(self) -> None:
        self.temporary_context.clear()
        self.closed = True

    def export_training_record(self) -> None:
        raise PermissionError("Owner request sessions are excluded from autonomous training")

    def persist_to_autonomous_memory(self) -> None:
        raise PermissionError("Owner request sessions are excluded from autonomous memory")
