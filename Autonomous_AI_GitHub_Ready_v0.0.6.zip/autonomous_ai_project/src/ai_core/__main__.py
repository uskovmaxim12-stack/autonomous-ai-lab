import json
from .config import ProjectConfig
from .journal import Journal
from .status import report

if __name__ == "__main__":
    config = ProjectConfig()
    config.prepare_directories()
    Journal(config.database).record("scaffold_started", {"version": "0.0.1"})
    print(json.dumps(report(), ensure_ascii=False, indent=2))
