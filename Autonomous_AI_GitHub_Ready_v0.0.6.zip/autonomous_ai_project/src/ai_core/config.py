from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

@dataclass(frozen=True)
class ProjectConfig:
    root: Path = ROOT
    database: Path = ROOT / "memory" / "project_journal.sqlite3"
    checkpoints: Path = ROOT / "checkpoints"
    logs: Path = ROOT / "logs"
    virtual_world: Path = ROOT / "virtual_world"

    def prepare_directories(self) -> None:
        for path in (self.database.parent, self.checkpoints, self.logs, self.virtual_world):
            path.mkdir(parents=True, exist_ok=True)
