"""Durable infrastructure event journal. This is not the agent's learned memory."""
import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

class Journal:
    def __init__(self, database: Path):
        database.parent.mkdir(parents=True, exist_ok=True)
        self.database = database
        with self._connect() as connection:
            connection.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp_utc TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    payload_json TEXT NOT NULL
                )
            """)

    def _connect(self):
        connection = sqlite3.connect(self.database)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA foreign_keys=ON")
        return connection

    def record(self, event_type: str, payload: dict[str, Any] | None = None) -> int:
        if not event_type.strip():
            raise ValueError("event_type must not be empty")
        encoded = json.dumps(payload or {}, ensure_ascii=False, sort_keys=True)
        timestamp = datetime.now(timezone.utc).isoformat()
        with self._connect() as connection:
            cursor = connection.execute(
                "INSERT INTO events(timestamp_utc, event_type, payload_json) VALUES (?, ?, ?)",
                (timestamp, event_type, encoded),
            )
            return int(cursor.lastrowid)

    def recent(self, limit: int = 20) -> list[dict[str, Any]]:
        if limit < 1:
            raise ValueError("limit must be positive")
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT id, timestamp_utc, event_type, payload_json FROM events ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [
            {"id": row[0], "timestamp_utc": row[1], "event_type": row[2], "payload": json.loads(row[3])}
            for row in rows
        ]
