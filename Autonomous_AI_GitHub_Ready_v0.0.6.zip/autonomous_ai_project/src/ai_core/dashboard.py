"""Local research dashboard. Standard-library HTTP server; binds localhost only."""
from __future__ import annotations
import json, threading, time, traceback, webbrowser
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import torch
import torch.nn.functional as F
from .config import ProjectConfig
from .journal import Journal
from .neural_model import TinyTransformerLM
from .tokenizer import CharacterTokenizer

ROOT=ProjectConfig.root; UI=ROOT/"ui"; CORPUS=ROOT/"data"/"starter_corpus.txt"; CHECKPOINT=ROOT/"checkpoints"/"dashboard_current.pt"
STATE={"training":False,"stop":False,"step":0,"total":0,"train_loss":None,"val_loss":None,"device":"—","parameters":0,"started":None,"ended":None,"checkpoint":None,"phase":"idle","activity":"Ожидание запуска","logs":[],"history":[],"error":None}
LOCK=threading.RLock(); JOURNAL=Journal(ProjectConfig.database)

def log(message,kind="info"):
    item={"time":time.strftime("%H:%M:%S"),"kind":kind,"message":str(message)}
    with LOCK: STATE["logs"]=(STATE["logs"]+[item])[-250:]
    try: JOURNAL.record("dashboard."+kind,{"message":str(message)})
    except Exception: pass

def snapshot():
    with LOCK: d={k:v for k,v in STATE.items() if k not in ("stop",)}; d["logs"]=STATE["logs"][-100:]; d["history"]=STATE["history"][:]
    d["gpu"]=torch.cuda.get_device_name(0) if torch.cuda.is_available() else "CUDA не обнаружена"
    d["gpu_memory_mb"]=round(torch.cuda.memory_allocated()/1024**2,1) if torch.cuda.is_available() else 0
    d["cpu_threads"]=torch.get_num_threads(); return d

def train_worker(steps=100,batch=8,context=48,width=64,layers=2,heads=4,lr=0.0005):
    try:
        text=CORPUS.read_text(encoding="utf-8"); tok=CharacterTokenizer(text); ids=torch.tensor(tok.encode(text)); split=int(len(ids)*.9); train,val=ids[:split],ids[split:]
        device=torch.device("cuda" if torch.cuda.is_available() else "cpu"); model=TinyTransformerLM(len(tok.tokens),context,width,layers,heads,.1).to(device); opt=torch.optim.AdamW(model.parameters(),lr=lr)
        with LOCK: STATE.update(training=True,stop=False,step=0,total=steps,train_loss=None,val_loss=None,device=str(device),parameters=sum(p.numel() for p in model.parameters()),started=time.time(),ended=None,checkpoint=None,phase="training",activity="Обучение на локальном корпусе",error=None,history=[])
        log(f"Старт: {steps} шагов · {sum(p.numel() for p in model.parameters()):,} параметров", "training"); model.train()
        for s in range(1,steps+1):
            with LOCK:
                if STATE["stop"]: break
            limit=max(1,train.numel()-context-1); starts=torch.randint(0,limit,(batch,)); x=torch.stack([train[i:i+context] for i in starts.tolist()]).to(device); y=torch.stack([train[i+1:i+context+1] for i in starts.tolist()]).to(device)
            loss=F.cross_entropy(model(x).reshape(-1,len(tok.tokens)),y.reshape(-1)); opt.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1); opt.step()
            if s==1 or s%max(1,steps//40)==0 or s==steps:
                model.eval()
                with torch.no_grad():
                    vl=None
                    if val.numel()>context+2:
                        ix=torch.randint(0,val.numel()-context-1,(min(batch,4),)); vx=torch.stack([val[i:i+context] for i in ix.tolist()]).to(device); vy=torch.stack([val[i+1:i+context+1] for i in ix.tolist()]).to(device); vl=float(F.cross_entropy(model(vx).reshape(-1,len(tok.tokens)),vy.reshape(-1)).item())
                model.train(); r={"step":s,"train_loss":float(loss.item()),"validation_loss":vl}
                with LOCK: STATE.update(step=s,train_loss=r["train_loss"],val_loss=vl,history=(STATE["history"]+[r])[-300:])
                if s==1 or s%max(1,steps//10)==0 or s==steps: log(f"Шаг {s}/{steps} · train {loss.item():.4f}"+(f" · validation {vl:.4f}" if vl is not None else ""),"metric")
        torch.save({"model":model.state_dict(),"tokenizer":tok.state(),"config":{"context":context,"width":width,"layers":layers,"heads":heads},"history":STATE["history"]},CHECKPOINT)
        with LOCK: STATE.update(training=False,ended=time.time(),checkpoint=str(CHECKPOINT),phase="stopped" if STATE["stop"] else "trained",activity="Обучение остановлено" if STATE["stop"] else "Эксперимент завершён")
        log(f"Checkpoint сохранён: {CHECKPOINT.name}","success")
    except Exception as e:
        with LOCK: STATE.update(training=False,phase="error",activity="Ошибка",error=str(e),ended=time.time())
        log(traceback.format_exc(),"error")

def start_training(p):
    with LOCK:
        if STATE["training"]: return False,"Обучение уже идёт"
    o={"steps":int(p.get("steps",100)),"batch":int(p.get("batch",8)),"context":int(p.get("context",48)),"width":int(p.get("width",64)),"layers":int(p.get("layers",2)),"heads":int(p.get("heads",4)),"lr":float(p.get("lr",.0005))}
    if not 1<=o["steps"]<=5000 or not 1<=o["batch"]<=32 or o["width"]%o["heads"]: return False,"Параметры обучения недопустимы"
    threading.Thread(target=train_worker,kwargs=o,daemon=True).start(); return True,"Обучение запущено"

def infer(prompt,max_new=120):
    if not CHECKPOINT.exists(): return "Checkpoint пока отсутствует. Запусти обучение, чтобы создать экспериментальные веса."
    d=torch.load(CHECKPOINT,map_location="cpu",weights_only=False); t=CharacterTokenizer.from_state(d["tokenizer"]); c=d["config"]
    m=TinyTransformerLM(len(t.tokens),c["context"],c["width"],c["layers"],c["heads"],0); m.load_state_dict(d["model"]); m.eval()
    ids=[t.to_id[x] for x in prompt if x in t.to_id] or [0]; out=list(ids)
    with torch.no_grad():
        for _ in range(min(180,max_new)):
            logits=m(torch.tensor([out[-c["context"]:]]))[0,-1]; probs=torch.softmax(logits/.85,dim=-1); out.append(int(torch.multinomial(probs,1)))
    return t.decode(out[len(ids):])

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def send(self,body,ctype="application/json; charset=utf-8",code=200):
        b=body if isinstance(body,bytes) else body.encode(); self.send_response(code); self.send_header("Content-Type",ctype); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path).path
        if p=="/api/status": self.send(json.dumps(snapshot(),ensure_ascii=False)); return
        if p=="/api/health": self.send(json.dumps({"ok":True,"learning_isolated":True})); return
        if p=="/": self.send((UI/"index.html").read_bytes(),"text/html; charset=utf-8"); return
        if p.startswith("/ui/"):
            f=UI/p.removeprefix("/ui/")
            if f.is_file(): self.send(f.read_bytes(),"text/css; charset=utf-8" if f.suffix==".css" else "application/javascript; charset=utf-8"); return
        self.send(json.dumps({"error":"not found"}),code=404)
    def do_POST(self):
        p=urlparse(self.path).path; data=json.loads(self.rfile.read(int(self.headers.get("Content-Length",0))) or b"{}")
        if p=="/api/train":
            ok,msg=start_training(data); self.send(json.dumps({"ok":ok,"message":msg}),code=200 if ok else 409); return
        if p=="/api/stop":
            with LOCK: STATE["stop"]=True
            log("Запрошена остановка", "warning"); self.send(json.dumps({"ok":True})); return
        if p=="/api/chat":
            msg=str(data.get("message", ""))[:1000]
            if not msg.strip(): self.send(json.dumps({"error":"Сообщение пустое"}),code=400); return
            try: self.send(json.dumps({"ok":True,"reply":infer(msg),"learning_isolated":True,"notice":"Экспериментальная character-level модель генерирует продолжение текста; это ещё не семантический чат. Сеанс временный и не сохраняется."},ensure_ascii=False))
            except Exception as e: self.send(json.dumps({"ok":False,"error":str(e)}),code=500)
            return
        if p=="/api/clear_logs":
            with LOCK: STATE["logs"]=[]
            self.send(json.dumps({"ok":True})); return
        self.send(json.dumps({"error":"not found"}),code=404)

def main():
    import argparse
    a=argparse.ArgumentParser(); a.add_argument("--port",type=int,default=8765); a.add_argument("--host",default="127.0.0.1",help="Bind address; use 0.0.0.0 only inside a private Codespace"); a.add_argument("--open",action="store_true"); args=a.parse_args()
    ProjectConfig().prepare_directories(); server=ThreadingHTTPServer((args.host,args.port),H); url=f"http://{args.host}:{args.port}"; log(f"Лаборатория запущена на {args.host}:{args.port}","system"); print(f"Autonomous AI Lab: listening on {args.host}:{args.port}\nAgent internet access: disabled")
    if args.open: webbrowser.open(url)
    try: server.serve_forever()
    except KeyboardInterrupt: pass
    finally: server.server_close()
if __name__=="__main__": main()
