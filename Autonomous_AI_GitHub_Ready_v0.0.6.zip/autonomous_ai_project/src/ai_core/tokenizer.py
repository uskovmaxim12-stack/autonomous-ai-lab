"""Transparent character tokenizer; vocabulary is learned from the training corpus."""
class CharacterTokenizer:
    def __init__(self, text: str):
        chars = sorted(set(text))
        if not chars:
            raise ValueError("Cannot build vocabulary from empty text")
        self.tokens = chars
        self.to_id = {char: index for index, char in enumerate(chars)}
        self.to_char = {index: char for char, index in self.to_id.items()}

    def encode(self, text: str) -> list[int]:
        unknown = set(text) - set(self.to_id)
        if unknown:
            raise ValueError(f"Text contains tokens outside vocabulary: {sorted(unknown)!r}")
        return [self.to_id[char] for char in text]

    def decode(self, ids: list[int]) -> str:
        return "".join(self.to_char[int(index)] for index in ids)

    def state(self) -> dict:
        return {"tokens": self.tokens}

    @classmethod
    def from_state(cls, state: dict):
        instance = cls("".join(state["tokens"]))
        return instance
