"""Train the first from-scratch language-model experiment on a local text corpus."""
from __future__ import annotations
import argparse, json, random
from pathlib import Path
import torch
import torch.nn.functional as F
from .neural_model import TinyTransformerLM
from .tokenizer import CharacterTokenizer
from .config import ProjectConfig


def make_batches(encoded: torch.Tensor, context: int, batch_size: int, device: torch.device):
    if encoded.numel() <= context + 1:
        raise ValueError(f"Corpus must contain more than {context + 1} tokens")
    max_start = encoded.numel() - context - 1
    starts = torch.randint(0, max_start + 1, (batch_size,))
    x = torch.stack([encoded[i:i + context] for i in starts.tolist()]).to(device)
    y = torch.stack([encoded[i + 1:i + context + 1] for i in starts.tolist()]).to(device)
    return x, y


def train(args):
    torch.manual_seed(args.seed)
    random.seed(args.seed)
    text = Path(args.corpus).read_text(encoding="utf-8")
    tokenizer = CharacterTokenizer(text)
    ids = torch.tensor(tokenizer.encode(text), dtype=torch.long)
    split = int(len(ids) * 0.9)
    train_ids, validation_ids = ids[:split], ids[split:]
    device = torch.device("cuda" if torch.cuda.is_available() and not args.cpu else "cpu")
    model = TinyTransformerLM(len(tokenizer.tokens), args.context, args.width, args.layers, args.heads, args.dropout).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate)
    config = ProjectConfig(); config.prepare_directories()
    history = []
    model.train()
    for step in range(1, args.steps + 1):
        x, y = make_batches(train_ids, args.context, args.batch_size, device)
        logits = model(x)
        loss = F.cross_entropy(logits.reshape(-1, len(tokenizer.tokens)), y.reshape(-1))
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        if step % args.report_every == 0 or step == args.steps:
            model.eval()
            with torch.no_grad():
                vx, vy = make_batches(validation_ids, args.context, args.batch_size, device)
                val_loss = F.cross_entropy(model(vx).reshape(-1, len(tokenizer.tokens)), vy.reshape(-1)).item()
            model.train()
            record = {"step": step, "train_loss": float(loss.item()), "validation_loss": val_loss}
            history.append(record)
            print(json.dumps(record, ensure_ascii=False))
    checkpoint = config.checkpoints / f"lm_experiment_{args.steps}steps.pt"
    torch.save({"model": model.state_dict(), "tokenizer": tokenizer.state(), "config": vars(args), "history": history}, checkpoint)
    print(f"Checkpoint saved: {checkpoint}")
    print(f"Device: {device}; parameters: {sum(p.numel() for p in model.parameters()):,}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--corpus", default="data/starter_corpus.txt")
    parser.add_argument("--steps", type=int, default=500)
    parser.add_argument("--report-every", type=int, default=50)
    parser.add_argument("--context", type=int, default=64)
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--width", type=int, default=128)
    parser.add_argument("--layers", type=int, default=3)
    parser.add_argument("--heads", type=int, default=4)
    parser.add_argument("--dropout", type=float, default=0.1)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--cpu", action="store_true")
    args = parser.parse_args()
    train(args)

if __name__ == "__main__":
    main()
