# Experiment 001 — Character-level causal language model

**Status:** Completed smoke experiment; not an intelligence milestone.

## Setup
- Model: randomly initialized causal Transformer
- Tokenization: character-level vocabulary extracted from the corpus
- Corpus: `data/starter_corpus.txt` (975 characters; small hand-written Russian/English seed)
- Parameters: 18,720
- Context: 32 characters
- Width: 32
- Transformer blocks: 1
- Attention heads: 2
- Batch size: 4
- Optimizer: AdamW
- Learning rate: 0.0003
- Updates: 50
- Device: CPU in this test environment
- No pretrained weights, external AI or Internet access used by the experiment

## Measurements
| Step | Training loss | Validation loss |
|---:|---:|---:|
| 10 | 4.3012 | 4.2977 |
| 20 | 4.2132 | 4.2590 |
| 30 | 4.1525 | 4.1816 |
| 40 | 4.0859 | 4.1573 |
| 50 | 4.0193 | 4.0962 |

Initial evaluation before updates: training loss 4.3577; validation loss 4.3485.

## Interpretation
Loss decreased on both training and held-out validation samples during this short experiment. This supports that the implementation and optimizer are updating parameters and that the model is fitting sequence statistics in this tiny corpus. It does not demonstrate language understanding, useful generation, reasoning, autonomy, consciousness or generalization beyond the measured setup.

## Artifact
`checkpoints/lm_experiment_50steps.pt` contains the model weights, tokenizer vocabulary, experiment arguments and recorded loss values.

## Next tests
- Inspect generated continuations qualitatively and quantitatively.
- Improve data splitting and ensure the validation set is not too small.
- Compare multiple random seeds.
- Test memorization versus generalization with held-out examples.
- Verify CUDA training on the owner's PC.
- Expand training data carefully and document provenance.
