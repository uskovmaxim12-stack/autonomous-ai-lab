# Handoff: Continue this project with another AI

## Instructions to the next AI
You are continuing a local research project to build an autonomous learning system and a synthetic virtual Internet. Read this file and all documents in `docs/` before changing code.

### Non-negotiable constraints
- Do not use third-party AI models, AI APIs or real external Internet for the agent.
- The owner now wants a GitHub-publication-ready repository and works from a phone. Prepare repository structure and Codespaces workflow. Do not publish/push to a remote repository unless the owner explicitly identifies the target repository and confirms publication.
- Do not replace intelligence with scripted responses, behavior trees, fixed dialogue, hand-coded policies or scenario lists. Scripts are infrastructure only.
- The neural learner must be genuinely trained from scratch. Do not silently load pretrained weights.
- Do not claim consciousness, human feelings, learning progress or metrics without evidence.
- Keep the synthetic world local and ensure actual network isolation is established before running the autonomous agent.
- Do not delete or overwrite data/checkpoints without backup and explicit authorization.
- Avoid asking repetitive conceptual questions. Make reasonable engineering choices, document assumptions, and ask only when a decision materially affects the project or requires owner approval.

### User and hardware context
The owner is a 14-year-old student who prefers concise Russian explanations, practical progress, complete copy-ready files and clear steps. Current local PC: Windows 10, Intel i7-12700KF, 64 GB RAM, RTX 5060 Ti 16 GB. Aim for free local tools. Do not overpromise scale.

### Agreed project vision
An independent neural learner with a starter foundation roughly metaphorically corresponding to age 3 (basic Russian/English, simple speech, arithmetic, logic, causality, common concepts), then unrestricted developmental progression. It learns from information and interaction, independently explores, creates goals, questions, hypotheses, experiments and skills. It has cognitive, individual-profile and computational affective components. It uses working, long-term, episodic, semantic and procedural memory, and gradually learns to manage memory. It lives in a local interconnected synthetic Internet/world (search, knowledge resources, documentation, social spaces, communication, office/code/terminal/creative tools, games, fictional organizations/economy/news/services). Owner can chat, speak, monitor, teach and collaborate. It should run while the computer is on, including unattended periods; overnight learning/consolidation is desired. Monitor must show actual metrics, goals, experiments, memory/skill changes, resource use, events, logs and checkpoint tests. Candidate model updates must be evaluated and rollback-capable.

#### New owner requirements (2026-11-21)
- The synthetic world must contain both good and bad, positive and negative conduct, morally complex situations, deception, manipulation, misinformation, conflict, cooperation, different viewpoints and consequences. The learner should develop and revise moral concepts through evidence and experience, not be handed a hard-coded morality answer key. Risky scenarios must stay safely simulated and isolated.
- The agent must interact with simulated sites/apps: navigate pages, click links/buttons, type into search/forms, submit, scroll, use menus and tools, and cause local simulated state changes. The owner must be able to see/replay the page and actions, including timestamps, targets and outcomes. Log attempted actions separately from successful changes.
- The agent is autonomous by default and should continue selecting activities, goals, exploration and learning without waiting for owner prompts. Run continuously while the local host is available; the runtime needs scheduling, checkpoints and recovery. Owner can observe, pause or stop. A powered-off computer cannot perform local work.
- Prepare a GitHub-ready repository because the owner works from a phone. Do not publish/push until the owner explicitly confirms the target repository and publication.

## Current status — repository preparation v0.0.6
The project includes a small randomly initialized character-level Transformer experiment, corpus-derived tokenizer, manual training harness, SQLite event journal, tests, and a browser dashboard. A GitHub Actions workflow and Codespaces devcontainer are included for phone-based development. The dashboard is not an autonomous agent; no synthetic Internet, independent goal system, mature memory, voice or semantic chat is implemented. Owner real-Internet shortcuts are for the owner only. The model has no public-Internet client. Dashboard has no authentication: keep Codespaces forwarded port private.

### How to continue
1. Inspect source, tests, requirements and all docs.
2. Verify Python environment and make the scaffold pass smoke tests.
3. Work in small, testable milestones. Prefer complete files over fragments.
4. Update `PROJECT_SPEC.md`, `ARCHITECTURE.md`, `DECISIONS.md`, `ROADMAP.md`, `CHANGELOG.md` and this handoff when decisions or implementation status change.
5. Create a dated local backup before risky changes; keep checkpoints and data out of source commits by default.
6. First technical milestone: a modest neural network built from scratch and trained from scratch on a narrowly scoped task, with honest train/validation metrics and tests. This is a proof of learning, not general intelligence.
7. Compare learning approaches experimentally, including continual/incremental versus consolidation training; evaluate catastrophic forgetting.
8. Keep a clear separation between learned cognitive behavior and infrastructure/world mechanics.
9. At each milestone, explain what actually works, how to run it, test results, limitations and next step.

## Suggested prompt
“Continue the Autonomous AI project from these files. First read PROJECT_CONTEXT_MASTER.md, README.md and every document in docs/. Respect all constraints: no third-party AI/API or real Internet for the learner, no scripted intelligence, phone-first development, and private Codespaces port forwarding only because the dashboard has no authentication. Inspect current code and tests. Do not repeat settled conceptual questions. Work on the next incomplete roadmap milestone, implement complete files, run tests, report verified results, and update project docs/changelog/handoff. Do not publish to a remote repository until the owner confirms the target repository and publication.”

### Latest verified experiment
Experiment 001 is documented in `docs/EXPERIMENT_001.md`. The small Transformer is implemented in `src/ai_core/neural_model.py`; the tokenizer and training script are in their respective modules. A 50-step CPU run decreased both training and validation loss. The checkpoint is available in `checkpoints/` in the handoff archive. Do not interpret this as an autonomous intelligence.

## New owner interaction requirement
Owner can chat with the learner and browse the synthetic Internet independently. Ordinary owner requests are strictly isolated: pinned model/checkpoint and knowledge snapshot, temporary session context, read-only world snapshot, no training, autonomous memory, goals, replay-buffer ingestion, or world mutations. Temporary context is discarded on close. Any future teaching must be a separate opt-in workflow. See `PROJECT_SPEC.md` section 16 and `ARCHITECTURE.md`. `src/ai_core/interaction_policy.py` is a standalone guardrail primitive only; do not claim end-to-end isolation is implemented until integration tests cover model/chat/world/training paths.

### Dashboard (v0.1)
- On a local host run `python -m src.ai_core.dashboard --open`; it binds to 127.0.0.1:8765.
- In a private GitHub Codespace run `python -m src.ai_core.dashboard --host 0.0.0.0 --port 8765`; open the forwarded port from the Codespaces Ports tab and keep it Private. The dashboard has no authentication; never expose the forwarded port publicly.
- Tabs: overview; temporary frozen checkpoint generation; training; event logs; owner-only Internet links/search; admin diagnostics.
- Dashboard training uses a fresh random model and starter corpus, saves `checkpoints/dashboard_current.pt`; stop button requests graceful stop after current step.
- Owner chat is only character-level continuation, not semantic chat. Requests are not stored or trained on.
- Internet tab opens real external pages in the owner's browser only. The agent backend has no external-network client.
- Autonomous agent, synthetic browser/world and goal formation are still not implemented.


## Phone-first GitHub workflow
- Keep the repository Private during experimentation.
- Use `.devcontainer/devcontainer.json` to create a Python 3.11 Codespace; it installs `requirements-dev.txt` and forwards port 8765.
- `.github/workflows/tests.yml` runs compile checks and pytest on push/PR.
- Do not commit `.env`, logs, SQLite runtime databases, or model checkpoints.
- No license is selected; do not add one without owner decision.
