# Architecture — evolving document

## Intended layers
1. **Neural learner** — from-scratch trainable model(s); cognition is not hard-coded.
2. **Perception / representation** — encode text and eventually other modalities from local synthetic inputs.
3. **World interface** — observe and act through a constrained API in the virtual world.
4. **Learning loop** — experience collection, prediction/learning signals, training, evaluation and transfer tests.
5. **Memory system** — working, episodic, semantic, procedural; local durable store plus learned retrieval/consolidation.
6. **Autonomy and goal discovery** — learned prioritization and exploration; no scripted “personality” pretending to be cognition.
7. **Synthetic world** — local services/content/state, simulated users, tools and feedback; intentionally diverse and morally mixed, with causal consequences rather than a pre-scripted moral answer key.
8. **Interactive browser/workspace** — learned agent actions through a local interface: navigation, links, clicks, typing, forms, menus, scrolling and tool operations; every action and state change is observable/auditable.
9. **Autonomous runtime** — scheduler, activity loop, recovery, resource budgets and continuous operation while host is available; owner observation is not a prerequisite for agent activity.
10. **Affective/individual state** — learned or adjustable computational signals that influence attention, priorities and communication; not proof of subjective experience.
11. **Interface** — chat, later voice, monitoring console and collaborative actions.
12. **Runtime/safety** — resource scheduler, process supervision, isolation, checkpointing, audit events and tests.

## Implementation order
Build a transparent foundation first: project configuration, durable event/experience journal, tests and runtime status. Then establish a small neural model trained from scratch and verify it learns a narrowly defined task. Only after that add world interfaces, autonomous exploration and broader learning. Keep every stage measurable and replaceable.

## Architectural cautions
- Do not begin with an enormous model or claim general intelligence.
- Do not use scripted actions as substitutes for learned behavior.
- Avoid training on unbounded noisy synthetic content without evaluation.
- Prevent catastrophic forgetting with replay, multi-task evaluation, regularization or other methods to be experimentally compared.
- Treat the virtual Internet as a world simulation with coherent state, not a collection of static text files. Implement browser-like interaction primitives and observable state changes, not merely page-reading. The world must contain both positive and negative examples, competing perspectives and consequences, without encoding a fixed morality script into the learner. Keep risky scenarios safely abstract/contained and disconnected from real-world execution.
- Network isolation must be verified at host/environment level.

## Current implementation
A small randomly initialized character-level Transformer experiment, tokenizer, manual training harness, SQLite event journal, unit tests and browser dashboard are implemented. The dashboard supports a temporary character-level continuation session, not semantic dialogue. The autonomous agent, synthetic browser/world, goal formation, mature memory and continuous learning scheduler are not implemented. GitHub Actions and a Python 3.11 Codespaces devcontainer support phone-first development. The dashboard has no authentication; forwarded Codespaces port must remain private.

## Phase 1 initial experiment (implemented)
- `TinyTransformerLM`: randomly initialized causal Transformer language model.
- `CharacterTokenizer`: vocabulary derived only from the local corpus.
- `train_lm.py`: sampling, next-token objective, optimizer, validation loss and checkpoint serialization.
- Starter corpus is a small editable local seed, not pretrained weights.
- First CPU experiment: 18,720 parameters, 50 updates, context 32, width 32, 1 block, 2 heads. Training loss decreased from 4.358 to 4.019; validation loss decreased from 4.348 (initial measurement) to 4.096 by step 50. This is a small preliminary result only.
- A larger model, better tokenizer, larger corpus, generation/evaluation suite and robust checkpoint metadata remain future work.

## Owner request isolation
Add a separate `Owner Request Session` boundary. At session start, pin the current model checkpoint and knowledge/memory snapshot. Give the session a temporary context/workspace and, for browsing, a read-only isolated snapshot of the synthetic world. Its request, search results and interaction events must not enter the autonomous event journal, episodic/semantic memory, training corpus, replay buffer, goal manager, or checkpoint trainer. On close, discard temporary context. Owner UI history, if retained, belongs to a separate owner-side store and is inaccessible to the learner. Do not merge session context after the request or during overnight consolidation. Explicit teaching must be a separate opt-in workflow with clear review and provenance.

A policy primitive is introduced in `src/ai_core/interaction_policy.py`; it is currently standalone and not connected to inference or world-browser code. Tests verify its guardrails, not end-to-end model isolation. The synthetic Internet remains local and offline; this requirement does not authorize real Internet/API access.
