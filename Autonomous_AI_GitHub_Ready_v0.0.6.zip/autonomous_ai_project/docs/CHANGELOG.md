# Changelog

## 0.0.1 — Initial local scaffold
- Recorded project requirements and core principles.
- Added architecture outline, decisions, roadmap and handoff prompt.
- Added SQLite event journal and local status report.
- No neural learner, agent, virtual world or network integration implemented yet.

## 0.0.2 — First neural learner experiment
- Added a randomly initialized causal Transformer language model.
- Added corpus-derived character tokenizer and next-token training harness.
- Added small Russian/English starter corpus.
- Added model-shape/tokenizer tests.
- Verified CPU training for 50 steps; training loss 4.301 at step 10 to 4.019 at step 50; validation loss 4.298 at step 10 to 4.096 at step 50.
- Saved experimental checkpoint `lm_experiment_50steps.pt`.
- This remains a language-model experiment, not an autonomous agent.


## 0.0.3 — Autonomy and interactive synthetic-world requirements
- Specified morally diverse synthetic content, including positive and negative examples, conflicting viewpoints, deception, misinformation and consequences, for the learner's own concept formation.
- Added simulated browser/workspace interactions: navigation, clicking, typing, forms, menus, scrolling and tool use.
- Added requirement for visible live/replay action tracking and audit events with attempted-vs-successful actions.
- Clarified autonomous continuous activity while the host is available, with scheduling, recovery and owner pause/stop controls.
- Expanded handoff documentation for continuation by another AI.

## v0.0.4 — Owner request isolation (requirements + policy primitive)
- Specified owner chat and owner browsing of the synthetic Internet as a separate isolated mode.
- Requests use a frozen checkpoint and isolated world snapshot; no autonomous-memory, goal, replay, training, or world-state updates.
- Added standalone `OwnerRequestSession` policy primitive and tests for rejection of training/memory export and cleanup.
- Explicitly documented that this primitive is not yet integrated into the model, chat, or browser.

## v0.0.5 — Local Lab UI foundation
- Added localhost dashboard with separated overview, model-session, training, logs, owner-only Internet, and admin tabs.
- Added live training control/metrics, loss chart, logs and checkpoint saving.
- Added temporary frozen-checkpoint text generation; request text is not stored in project journal, memory or training corpus.
- Owner external search opens in their browser; no backend Internet access is added to the agent.
- UI explicitly reports autonomous agent and synthetic Internet as not implemented.


## 0.0.6 — Phone-first GitHub repository preparation
- Added GitHub Actions workflow for Python compile checks and pytest.
- Added Python 3.11 Codespaces devcontainer with port 8765 forwarding.
- Dashboard accepts an explicit bind host; localhost remains the default, while `0.0.0.0` is documented only for private Codespaces forwarding.
- Replaced computer-centric setup instructions with Android phone + GitHub/Codespaces workflow.
- Updated handoff and project docs to reflect the owner's phone-only workflow and current implementation status.
- Runtime databases, logs, secrets and model checkpoints remain excluded from source control.
- No repository was created or published by this packaging step; the archive is ready for owner-controlled upload.
