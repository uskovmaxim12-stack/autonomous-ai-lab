# Roadmap

## Phase 0 — Project foundation (current)
- [x] Requirements, architecture outline, decision log and handoff document
- [x] Local project scaffold
- [x] SQLite event journal
- [x] Status report
- [ ] Environment setup and smoke test on owner's machine

## Phase 1 — Neural learning proof
- [ ] Select and document a small from-scratch architecture appropriate to available hardware
- [ ] Implement deterministic training/evaluation harness
- [ ] Define a tiny task and data-generation pipeline that does not encode answers into agent behavior
- [ ] Demonstrate measurable learning and generalization to held-out examples
- [ ] Save/load checkpoint; test recovery

## Phase 2 — Experience and memory
- [ ] Experience schema and observations/actions/results
- [ ] Working and episodic memory
- [ ] Retrieval and memory inspection
- [ ] Consolidation experiments; retention/forgetting tests

## Phase 3 — First synthetic environment
- [ ] Local world interface
- [ ] Small coherent simulated environment with observations, actions and consequences
- [ ] Feedback/reward or learning signal experiments
- [ ] Agent can explore and learn without hand-authored behavior policies

## Phase 4 — Autonomy
- [ ] Always-on runtime/supervisor while host is available, with restart recovery and checkpointing
- [ ] Autonomous activity scheduler; owner observation is not a prerequisite
- [ ] Goal discovery/prioritization experiments
- [ ] Hypothesis and experiment tracking
- [ ] Long-running task scheduling
- [ ] Activity monitor and truthful reports

## Phase 5 — Synthetic Internet expansion
- [ ] Local search/index
- [ ] Interactive browser interface: navigation, links, click targets, text fields, forms, buttons, scrolling and menus
- [ ] Observable site state/action timeline and live/replay view
- [ ] Morally and informationally diverse content (beneficial/harmful conduct, deception, conflicts, misinformation and consequences) for independent concept formation; keep hazardous scenarios contained
- [ ] Linked knowledge sites, documentation and articles
- [ ] Simulated communication/social interactions
- [ ] Tools and creative environments
- [ ] Coherent world state and simulated economy/institutions

## Phase 6 — Skills and modalities
- [ ] Skill evaluation framework
- [ ] Simple drawing/visual task experiment
- [ ] Additional modalities only when an actual learning pathway is implemented

## Phase 7 — Interface
- [ ] Console/dashboard
- [ ] Chat
- [ ] Voice I/O
- [ ] Owner collaboration and teaching tools

## Phase 8 — Continuous learning and safe updates
- [ ] Offline consolidation cycle
- [ ] Candidate checkpoint evaluation
- [ ] Regression suite
- [ ] Promotion/rollback protocol
- [ ] Resource-aware scheduler

Phases may be revised as experiments reveal limitations. No phase is considered complete without tests and documented evidence.

### Phase 1 progress
- [x] First randomly initialized causal Transformer implemented
- [x] Character tokenizer built from corpus
- [x] Training and validation harness implemented
- [x] Checkpoint save implemented
- [x] CPU smoke training completed (50 updates; both train and validation loss decreased)
- [ ] More robust corpus/data splits and evaluation
- [ ] Generation quality inspection and task-based evaluation
- [ ] GPU environment verification on owner's PC

### Owner interaction (new requirement)
- [ ] Build owner chat against a pinned/frozen learner checkpoint.
- [ ] Add owner-side synthetic-world browser on an isolated snapshot.
- [ ] Separate owner session history from agent memory and training storage.
- [ ] Add explicit, reviewable opt-in teaching workflow (not ordinary chat).
- [ ] Integration tests prove owner messages/search/action results never reach autonomous training or memory ingestion.
- [ ] Display session mode prominently: `OWNER SESSION — LEARNING ISOLATED`.

## v0.1 dashboard foundation
- [x] Localhost-only web dashboard with overview, logs, training, owner-only Internet shortcuts and admin status
- [x] Manual training control and live metrics/checkpoint save
- [x] Temporary inference interface isolated from training/memory
- [ ] Validate startup and training on owner Windows/GPU
- [ ] Replace character-level continuation with a task-specific evaluation interface; do not label it semantic chat
- [ ] Real synthetic-world browser/action simulation and autonomous learner remain future work
