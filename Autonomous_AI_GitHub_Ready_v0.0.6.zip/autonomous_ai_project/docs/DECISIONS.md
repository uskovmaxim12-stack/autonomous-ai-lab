# Decision Record

## D-001 — Local-only, no external AI
Accepted. No third-party model, AI API or real external Internet for agent operation.

## D-002 — Neural learning must be genuine
Accepted. Trainable network weights and learning algorithms must perform the cognitive work. Infrastructure scripts are allowed; scripted cognition is not.

## D-003 — Autonomous development
Accepted. Agent independently explores, sets goals, asks questions, experiments and learns. Owner may observe, interact and collaborate.

## D-004 — Learning from both materials and interaction
Accepted. Both information study and active interaction/feedback are core.

## D-005 — Initial foundation
Accepted. Small foundational knowledge/skills approximating early-childhood basics, including Russian/English, simple speech, arithmetic, logic and causal associations. It is not a pretrained mature model or a fixed age limit.

## D-006 — Cognitive, individual and affective components
Accepted. Intelligence, developing preferences/profile and computational affect-like state are all desired; subjective consciousness is not assumed.

## D-007 — Interaction modes
Accepted. Text, voice, monitoring and collaborative activity are in scope.

## D-008 — Memory
Accepted. Working, long-term, episodic, semantic and procedural memory; agent learns memory management, with recoverability and auditability.

## D-009 — Local synthetic world
Accepted. A broad interconnected virtual Internet/world with services, content, tools and simulated participants, strictly isolated from real external network.

## D-010 — Local-first and no remote publication
Accepted. Work locally; no GitHub push/upload unless the owner explicitly asks.

## D-011 — Portability/handoff
Accepted. Keep self-contained documents, current state, changelog, code, tests and a continuation prompt so another AI can take over.

## D-012 — No fake metrics or unsupported claims
Accepted. Report only measured training/evaluation values and actual completed work.

## D-013 — Hardware constraints
Accepted. Start with research-scale experiments on the user's local PC. Frontier-scale training is outside current feasibility.

## D-014 — Learning schedule
Not yet implemented/fully specified. Explore both online/incremental learning and offline consolidation cycles; evaluate stability, forgetting and checkpoint safety before selecting final mechanics.


## 2026-11-21 — Morally diverse world and active interactive agent
- The synthetic Internet/world must include both positive and negative examples and morally complicated situations. The learner should infer/revise moral concepts through observation, comparison, dialogue, consequences and reflection—not a fixed scripted moral-answer table.
- Risky or harmful scenarios are contained simulations and must not connect to real services or provide real-world harmful execution pathways.
- The agent should interact with simulated websites and applications, not just read pages: navigation, links, buttons, text fields, forms, menus, scrolling and tools. Each attempted action and resulting state change is observable to the owner through live/replay UI and an audit log.
- Autonomy is the default: the agent selects activities and continues without waiting for owner input while the host/runtime is available. Owner controls include pause, stop and inspect. “Always on” is limited by host power/availability.
- Owner explicitly requested local coding only; no pushing/uploading to GitHub or other remote services.

## Decision: owner-request sessions do not teach the autonomous learner
Owner requests are handled in a temporary isolated context using a frozen checkpoint and snapshot. By default, requests, results, browsing and intermediate work are excluded from autonomous memory, training, replay, goal changes and world mutations. User-side chat history may be stored separately for convenience but cannot be learner-readable. Any future teaching mode must be explicit, separate, and reviewed/confirmed.

## Decision: owner may browse the synthetic Internet independently
The owner should be able to interact with the local synthetic Internet through its own UI session. It defaults to an isolated/read-only snapshot so the owner's actions cannot alter the autonomous learner's environment. No real external Internet connection is introduced.
