# Project Specification — Autonomous AI & Synthetic Virtual Internet

## 1. Purpose
Create a locally running, autonomous learning system with its own neural network, persistent memory, developing capabilities and individual behavioral profile. It should grow through experience rather than be a scripted chatbot. It is a research prototype, not a claim of human-equivalent consciousness.

## 2. Core principles
1. Neural intelligence is learned: trainable parameters and learning mechanisms must do the cognitive work.
2. No borrowed AI models, external AI services, or APIs.
3. No real external Internet. The simulated Internet/world is local and synthetic; isolation must ultimately be enforced at OS/network level, not merely by application convention.
4. Scripts may implement infrastructure, simulation mechanics, persistence, scheduling, monitoring, tests and safety. They may not encode fake intelligence as fixed dialogue/decision scripts.
5. The agent is autonomous: it chooses what to explore, questions, hypotheses, experiments and longer-term goals.
6. It learns both by consuming information and by acting/interacting and receiving feedback.
7. It runs continuously while the host is available. When the host is off, local computation stops unless a separate always-on host is provided.
8. The project is free-software/tooling-first and initially uses the owner's computer. Hardware and energy are real constraints.
9. Prepare a GitHub-ready repository, CI and Codespaces setup. Do not publish or push until the owner confirms the target repository and publication.
10. Maintain a portable project record so another AI can continue from files alone.

## 3. Initial developmental foundation
A deliberately small starting foundation approximating a young learner's early capabilities (metaphorical age ~3, not a biological equivalence): Russian and English basics, simple language, basic arithmetic, elementary logic, causal associations, common concepts, and ability to retain experience. This is starter training/data, not a mature model or a hard age ceiling. No pretrained adult model is to be silently substituted.

## 4. Development
The system should be able to acquire new skills over time, potentially including drawing or other modalities, through learning, practice, feedback and evaluation. Such milestones are experiments, not guaranteed timelines. A simple learned skill is distinct from building a high-quality generative image model from scratch.

## 5. Autonomy and goal formation
The agent should independently:
- choose activities and explore its world;
- form questions and hypotheses;
- select experiments and interpret results;
- develop longer-term goals and decompose them into tasks;
- revisit goals when new evidence or feedback changes priorities;
- learn from success, failure and interactions.

The design must not hardcode a fixed list of goals as if these were self-generated. Infrastructure may provide a world, available actions, limits and feedback.

## 6. Intelligence, individuality and affective model
All three are desired: cognitive skills, a developing individual profile (preferences/interests/communication style), and an affect-like computational state (e.g., curiosity, novelty, frustration-like signals, satisfaction signals) that may influence learning and priorities. These are computational mechanisms; do not claim that subjective human feelings or consciousness are established.

## 7. Virtual world / synthetic Internet
A local, interconnected simulation with diverse institutions and tools, such as:
- search and reference resources, encyclopedias, articles, documentation and courses;
- forums, social spaces, fictional users and conversation;
- email and communication tools;
- office tools, coding environments, terminals and development projects;
- drawing and creative tools, music, games;
- fictional companies, stores, economy, news and services.
The world should contain coherent, linked content and state, not isolated prompt snippets. It must include morally varied material and situations—benevolent and harmful conduct, honesty and deception, cooperation and conflict, competing viewpoints, misinformation, manipulation and consequences—so the learner can compare evidence and develop/revise its own moral concepts rather than merely recite a fixed morality script. Harmful scenarios remain contained simulations; they must not provide real-world execution, external connectivity or actionable instructions for real harm. The simulated world is generated/maintained locally and cannot route to real external services.

### 7.1 Interactive browsing / site actions
The agent must not merely read static pages. It should use a simulated browser-like interface with visible navigation and controls: open pages, follow links, click buttons, type into search and form fields, submit forms, scroll, switch tabs, use menus and interact with site-specific tools. Site state changes (e.g. a post drafted, a search submitted, a simulated message sent, a file saved) must be reflected in the world and in the monitor. Actions are executed against a local world API, never real sites. The owner can watch an activity replay/live view that shows the page, action, target, result and timestamp. Maintain an audit event trail and distinguish attempted actions from successful state changes. A site/tool catalog should be diverse and interconnected, with realistic affordances rather than a single generic page.

## 8. Learning channels
Both information study and interactive experience are required. The system should be able to observe, act, get feedback, test hypotheses, learn from examples and gradually transfer skills to new situations.

## 9. Memory
Use complementary memory types:
- working/short-term context;
- long-term storage;
- episodic records of experiences;
- semantic concepts and relationships;
- procedural skill/method memory.
The agent may learn memory management: relevance, consolidation, summarization, association, conflict detection, revising outdated beliefs and retrieval. Raw records should be recoverable; deletion/consolidation should not silently destroy important history. Memory contents must be inspectable and backed up.

## 10. Interaction with owner
All modes are in scope: text chat, voice, live activity/learning monitor, and collaborative activities where the owner can teach, suggest, provide feedback, introduce materials or projects. Interaction is one part of the agent's independent activity, not its entire purpose.

## 11. Monitoring and observability
A dashboard/console should show real data:
- current model/checkpoint and training stage;
- real loss and evaluation results where applicable;
- resource use and workload;
- current activity, goals, experiments and actions;
- memory changes, skill progress, events, errors and logs;
- checkpoint comparisons and promotion/rejection decisions;
- reports summarizing what changed and what was learned.
Provide auditable explanations based on recorded observations, hypotheses, actions, results and decision summaries. Do not expose or fabricate hidden chain-of-thought.

### 11.1 Live activity visualization
The monitoring interface should include a live or replayable browser/workspace view. Show navigation, page titles, clicks, typing/submission (with sensitive simulation data redacted where appropriate), state changes, errors, and the agent's concise action summaries. Provide pause/stop controls for the owner and a clear indicator of simulated versus real-world actions. Owner observation is passive by default; the agent should not wait for owner prompts to resume its own activity.

## 12. Offline/night cycle and model updates
While the host is running, the agent is intended to remain active by default: it autonomously selects exploration, learning, experiments, goals, rest/consolidation cycles and tasks without waiting for the owner. A supervisor/scheduler should recover from ordinary failures, checkpoint and resume, and expose activity/idle reasons. “Always active” means while the local host and runtime are powered and available; no computation occurs when the computer is off unless another host is provided. While active, the agent may accumulate experience, consolidate memory, train, test candidate checkpoints and compare them against the current version. Candidate updates should be promoted only after measurable evaluations and regression checks; retain rollback checkpoints. Never claim that a metric improved unless it was actually measured.

## 13. Safety, reliability and isolation
- Enforce network isolation outside the agent process (OS firewall or isolated environment); code-level checks are supplementary.
- Protect against crashes, corrupt state, invalid actions and resource exhaustion.
- Use bounded workloads, scheduling, checkpointing and graceful shutdown.
- No unapproved publication, remote access or external data transfer.
- Clearly distinguish simulated world actions from real-world actions.

## 14. Hardware reality
The owner currently works from an Android phone without a personal computer. Use GitHub Codespaces as an optional cloud development environment. Availability, compute, storage, GPU and free quotas depend on the GitHub account; Codespaces is not guaranteed always-on compute. Small CPU experiments are feasible; frontier-scale training from scratch is not.

## 15. Project management
Use versioned files, tests, changelog and explicit decisions. Do not push to GitHub or any remote without explicit permission. The project must be handoff-ready at all times.

## 16. Owner request sessions (strict learning isolation)
The owner can interact with both the agent and the same synthetic Internet/world through a user-facing interface. Owner requests are a separate, temporary mode—not part of the agent's autonomous life.
- The request is processed using the currently selected/frozen model checkpoint and knowledge/memory snapshot available at session start.
- Session-only context (request text, temporary search results, intermediate workspace) is not written into autonomous episodic/semantic memory, training corpora, replay buffers, goal queues, or model weights.
- No training or autonomous learning is triggered during or after an owner request. The request is not scheduled for later study.
- Owner exploration of the synthetic Internet uses an isolated snapshot/sandbox by default; it cannot mutate the agent's world state. Explicit collaborative mode, if added later, must be opt-in and separately designed, and still must not silently ingest owner interaction into training.
- Temporary session context is discarded at close. A separate user-side session history may be offered for the owner's convenience, but must not be readable as agent memory or training data.
- User requests can be handled with the learner's existing knowledge. The current implementation is not yet capable of reliable natural-language task completion; this is a future capability, not an existing feature.
- The user may choose to explicitly teach the agent in a separate, clearly labeled teaching workflow. This is distinct from ordinary requests and requires confirmation before material is admitted to learning.
