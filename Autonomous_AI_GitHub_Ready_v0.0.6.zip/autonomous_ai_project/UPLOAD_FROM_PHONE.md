# Upload this project to GitHub from an Android phone

This project archive contains the complete repository folder. GitHub does not unpack a ZIP into repository files automatically, so use this one-time Codespaces import.

## 1. Create an empty repository

1. Open `https://github.com/new` in your phone browser.
2. Repository name: `autonomous-ai-lab` (or another name you choose).
3. Choose **Private** while the experiment is under development.
4. Do not initialize with a README, license or `.gitignore`; create an empty repository.

## 2. Upload the ZIP

1. Open the new repository.
2. Choose **Add file → Upload files**.
3. Select `Autonomous_AI_GitHub_Ready_v0.0.6.zip` from your phone's Downloads.
4. Commit the ZIP to the default branch.

## 3. Create a Codespace and unpack

1. In the repository, choose **Code → Codespaces → Create codespace on main**.
2. When the browser-based editor opens, open its Terminal.
3. Paste this command as one line:

```bash
mkdir -p /tmp/ai-import && unzip -o Autonomous_AI_GitHub_Ready_v0.0.6.zip -d /tmp/ai-import && cp -a /tmp/ai-import/autonomous_ai_project/. . && rm -rf /tmp/ai-import Autonomous_AI_GitHub_Ready_v0.0.6.zip && python -m pip install -r requirements-dev.txt && git add -A && git commit -m "Add Autonomous AI Lab project" && git push
```

This unpacks the source into the repository root, installs dependencies, and commits the actual project files. If Git reports that there is nothing to commit, inspect the repository file list before retrying.

## 4. Start the dashboard

```bash
python -m src.ai_core.dashboard --host 0.0.0.0 --port 8765
```

Open the **Ports** tab in Codespaces and open port `8765`. Keep visibility set to **Private**. The dashboard currently has no authentication; never make this port public.

## 5. Run checks

```bash
python -m pytest -q
python -m compileall -q src tests
```

The repository also has GitHub Actions CI, which runs these checks after pushes and pull requests.

## Important limitations

- GitHub Codespaces availability, included hours/storage and billing depend on your account. A Codespace can stop when idle. It is not a guaranteed free, always-on server.
- GPU may not be available; the current experiment can run on CPU but may be slow.
- The dashboard has no login/password. Keep its forwarded port Private.
- The learner's synthetic Internet is not implemented yet. The current Internet tab is only for you, the owner.
- The current model session generates character-level text and is not a useful semantic chatbot.
