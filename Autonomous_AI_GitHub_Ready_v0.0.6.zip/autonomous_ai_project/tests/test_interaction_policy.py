import pytest

from src.ai_core.interaction_policy import OwnerRequestSession, OwnerSessionPolicy


def test_default_owner_session_is_learning_isolated():
    session = OwnerRequestSession("Explain gravity")
    session.add_temporary_context("Temporary search result")
    assert session.policy.allow_training_updates is False
    assert session.policy.allow_autonomous_memory_writes is False
    assert session.policy.allow_goal_updates is False
    assert session.policy.allow_experience_replay_ingestion is False
    assert session.policy.allow_world_mutations is False
    session.close()
    assert session.temporary_context == []
    assert session.closed is True


def test_session_cannot_export_to_training_or_memory():
    session = OwnerRequestSession("Do a task")
    with pytest.raises(PermissionError):
        session.export_training_record()
    with pytest.raises(PermissionError):
        session.persist_to_autonomous_memory()


def test_policy_rejects_learning_enabled_configuration():
    policy = OwnerSessionPolicy(allow_training_updates=True)
    with pytest.raises(ValueError):
        policy.validate()


def test_closed_session_cannot_accept_context():
    session = OwnerRequestSession("Task")
    session.close()
    with pytest.raises(RuntimeError):
        session.add_temporary_context("late data")
