import tempfile
import unittest
from pathlib import Path
from src.ai_core.journal import Journal

class JournalTests(unittest.TestCase):
    def test_records_and_reads_event(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = Journal(Path(directory) / "test.sqlite3")
            event_id = journal.record("test_event", {"value": 42})
            events = journal.recent(1)
            self.assertEqual(events[0]["id"], event_id)
            self.assertEqual(events[0]["event_type"], "test_event")
            self.assertEqual(events[0]["payload"]["value"], 42)

    def test_rejects_empty_event_type(self):
        with tempfile.TemporaryDirectory() as directory:
            journal = Journal(Path(directory) / "test.sqlite3")
            with self.assertRaises(ValueError):
                journal.record("   ")

if __name__ == "__main__":
    unittest.main()
