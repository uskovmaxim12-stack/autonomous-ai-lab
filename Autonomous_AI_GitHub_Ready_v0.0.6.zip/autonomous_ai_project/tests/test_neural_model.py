import unittest
import torch
from src.ai_core.neural_model import TinyTransformerLM
from src.ai_core.tokenizer import CharacterTokenizer

class NeuralModelTests(unittest.TestCase):
    def test_forward_shape_and_finite_values(self):
        model = TinyTransformerLM(vocab_size=17, context_length=12, width=32, layers=2, heads=4, dropout=0.0)
        x = torch.randint(0, 17, (3, 8))
        logits = model(x)
        self.assertEqual(tuple(logits.shape), (3, 8, 17))
        self.assertTrue(torch.isfinite(logits).all())

    def test_tokenizer_roundtrip(self):
        tokenizer = CharacterTokenizer("abc cab")
        self.assertEqual(tokenizer.decode(tokenizer.encode("cab")), "cab")

if __name__ == "__main__":
    unittest.main()
