# Autonomous AI Lab

**An experimental, from-scratch neural-learning research project.** The repository is a work in progress, not a finished autonomous intelligence.

> Current reality: the project contains a small randomly initialized character-level Transformer experiment and a browser dashboard. It does **not** yet contain an autonomous agent, synthetic Internet, independent goal formation, mature memory, voice, or semantic chatbot.

## Use it from a phone

You do not need a personal computer to edit the repository. The intended phone workflow is **GitHub + GitHub Codespaces** (Codespaces availability, free quota and billing depend on your GitHub account).

1. Create a repository on GitHub, preferably named `autonomous-ai-lab`. Keep it **Private** while the project is experimental.
2. Add the project files to the repository (upload the extracted project folder contents, not the ZIP file itself).
3. Open the repository in GitHub Codespaces: **Code → Codespaces → Create codespace on main**. On a phone, use the browser's desktop-site option if the Codespaces controls are hidden.
4. Wait for the dev container to finish installing dependencies.
5. In the Codespaces terminal, run:

   ```bash
   python -m src.ai_core.dashboard --host 0.0.0.0 --port 8765
   ```

6. Open the forwarded port **8765** from the Codespaces **Ports** tab. Keep its visibility **Private**. Do not make the port public.

Codespaces is a cloud development machine, not a permanently running free server. It can stop when idle, and its available compute/storage depend on account limits. Training may be slow or unavailable on GPU; this configuration is CPU-first.

## Run tests in Codespaces

```bash
python -m pytest -q
python -m compileall -q src tests
```

GitHub Actions runs the same checks on pushes and pull requests.

## What the dashboard currently does

- Overview: runtime state and actual experiment metrics.
- Training: manually starts a small from-scratch model training run and saves a checkpoint.
- Model session: temporary character-level continuation from a frozen checkpoint. This is **not** semantic question answering. Requests are not intentionally added to training data or the autonomous journal.
- Logs: infrastructure and experiment events.
- Owner Internet: shortcuts/search for the **owner's browser only**. The learner has no real Internet client.
- Admin: basic runtime diagnostics.

The dashboard binds to `127.0.0.1` by default. `--host 0.0.0.0` is intended only inside a private Codespace so GitHub can forward the port. Do not expose it publicly: this prototype has no authentication.

## Core principles

- Neural components must start from random initialization and learn from project data; no hidden pretrained model or third-party AI API.
- The agent's future Internet is a local synthetic world, not the real public Internet.
- Simulated actions, learning, memory and evaluation must be observable and honestly reported.
- Owner chat is a separate temporary mode and must not silently update the learner's knowledge, goals, memory or weights.
- Scripts may provide infrastructure and simulation mechanics, but must not impersonate learned intelligence with canned answers or behavior trees.
- The synthetic world should contain positive and negative examples and morally complex situations; risky events remain simulated and isolated.

## Project documentation

- [`UPLOAD_FROM_PHONE.md`](UPLOAD_FROM_PHONE.md) — exact Android phone upload and Codespaces setup steps.

- [`PROJECT_CONTEXT_MASTER.md`](PROJECT_CONTEXT_MASTER.md) — canonical project state and handoff context.
- [`docs/PROJECT_SPEC.md`](docs/PROJECT_SPEC.md) — agreed requirements.
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — architecture and current implementation.
- [`docs/DECISIONS.md`](docs/DECISIONS.md) — decisions and constraints.
- [`docs/ROADMAP.md`](docs/ROADMAP.md) — milestones.
- [`docs/HANDOFF.md`](docs/HANDOFF.md) — instructions for another AI.
- [`docs/CHANGELOG.md`](docs/CHANGELOG.md) — version history.

## Repository hygiene

Model checkpoints, runtime databases, logs, secrets and temporary files are excluded by `.gitignore`. Back them up separately before deleting or replacing them. No license is included yet; until a license is deliberately selected, do not assume others have permission to reuse the code.

## Current milestone

See `docs/ROADMAP.md`. The next major technical milestone is a minimal interactive synthetic environment with explicit observation/action/result records, followed by an autonomous exploration loop.
